﻿using System;
namespace Assignment2
{
    public struct Position
    {
        public float X, Y;

        public Position(float x, float y)
        {
            X = x; Y = y;
        }
    }
}
