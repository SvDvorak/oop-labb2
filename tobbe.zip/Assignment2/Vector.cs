﻿namespace Assignment2
{
	public struct Vector
	{
		public float X, Y;

		public Vector(float x, float y)
		{
			X = x; Y = y;
		}
	}
}
